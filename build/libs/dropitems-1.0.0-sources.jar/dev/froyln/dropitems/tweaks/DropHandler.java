package dev.froyln.dropitems.tweaks;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import fi.dy.masa.malilib.config.ConfigManager;
import fi.dy.masa.malilib.interfaces.IClientTickHandler;

import dev.froyln.dropitems.Reference;
import dev.froyln.dropitems.config.Configs;
import dev.froyln.dropitems.config.FeatureToggle;

public class DropHandler implements IClientTickHandler
{
    private static final DropHandler INSTANCE = new DropHandler();

    public static DropHandler getInstance()
    {
        return INSTANCE;
    }

    @Override
    public void onClientTick(class_310 mc)
    {
        if (FeatureToggle.TWEAK_AUTO_DROP_DUMMY_ON_FULL.isEnabled() && this.isInventoryFull(mc))
        {
            this.dropDummyItems(mc);
        }
    }

    public void dropAllDummyItems()
    {
        class_310 mc = class_310.method_1551();

        if (mc.field_1724 == null || mc.field_1724.field_7512 == null)
        {
            return;
        }

        this.dropDummyItems(mc);
    }

    public void addHeldItem()
    {
        class_310 mc = class_310.method_1551();

        if (mc.field_1724 == null)
        {
            return;
        }

        class_1799 held = mc.field_1724.method_6047();

        if (held.method_7960())
        {
            return;
        }

        class_2960 id = class_7923.field_41178.method_10221(held.method_7909());

        if (id == null)
        {
            return;
        }

        List<String> strings = new ArrayList<>(Configs.DUMMY_ITEMS.getStrings());
        String entry = id.toString();

        if (strings.contains(entry))
        {
            return;
        }

        strings.add(entry);
        Configs.DUMMY_ITEMS.setStrings(strings);
        ConfigManager.getInstance().onConfigsChanged(Reference.MOD_ID);
    }

    public void removeHeldItem()
    {
        class_310 mc = class_310.method_1551();

        if (mc.field_1724 == null)
        {
            return;
        }

        class_1799 held = mc.field_1724.method_6047();

        if (held.method_7960())
        {
            return;
        }

        class_2960 id = class_7923.field_41178.method_10221(held.method_7909());

        if (id == null)
        {
            return;
        }

        List<String> strings = new ArrayList<>(Configs.DUMMY_ITEMS.getStrings());
        strings.removeIf(s -> id.equals(class_2960.method_12829(s)));

        if (strings.equals(Configs.DUMMY_ITEMS.getStrings()) == false)
        {
            Configs.DUMMY_ITEMS.setStrings(strings);
            ConfigManager.getInstance().onConfigsChanged(Reference.MOD_ID);
        }
    }

    private void dropDummyItems(class_310 mc)
    {
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1724.field_7512 == null)
        {
            return;
        }

        if (mc.field_1724.field_7512.field_7763 != 0)
        {
            return;
        }

        List<class_2960> dummyIds = this.getDummyIds();

        if (dummyIds.isEmpty())
        {
            return;
        }

        class_1661 inventory = mc.field_1724.method_31548();

        for (class_1735 slot : mc.field_1724.field_7512.field_7761)
        {
            // Only the main + hotbar slots (index 0-35 in the player inventory); never armor/offhand
            if (slot.field_7871 == inventory && slot.method_34266() < 36)
            {
                class_1799 stack = slot.method_7677();

                if (stack.method_7960() == false && this.isDummy(stack, dummyIds))
                {
                    mc.field_1761.method_2906(0, slot.field_7874, 1, class_1713.field_7795, mc.field_1724);
                }
            }
        }
    }

    private boolean isInventoryFull(class_310 mc)
    {
        if (mc.field_1724 == null || mc.field_1724.field_7512 == null || mc.field_1724.field_7512.field_7763 != 0)
        {
            return false;
        }

        for (class_1799 stack : mc.field_1724.method_31548().field_7547)
        {
            if (stack.method_7960())
            {
                return false;
            }
        }

        return true;
    }

    private List<class_2960> getDummyIds()
    {
        List<class_2960> ids = new ArrayList<>();

        for (String entry : Configs.DUMMY_ITEMS.getStrings())
        {
            class_2960 id = class_2960.method_12829(entry.trim());

            if (id != null)
            {
                ids.add(id);
            }
        }

        return ids;
    }

    private boolean isDummy(class_1799 stack, List<class_2960> dummyIds)
    {
        class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());

        return id != null && dummyIds.contains(id);
    }
}
